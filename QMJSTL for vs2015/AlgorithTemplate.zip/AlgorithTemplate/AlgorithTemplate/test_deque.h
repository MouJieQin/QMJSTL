#pragma once
#ifndef _TEST_DEQUE_
#define _TEST_DEQUE_
#include<deque>
#include"deque_qmj.h"
#include"test.h"


void test_deque()
{
	std::vector<int>data_size
	{5000000};

	random_data_product(data_size, vt_data, insert_data)

		time_counter(
			"push_back"
			,
		std::deque<bb>std_;
	for (auto i : vt_data)
		std_.push_back(b);
	,
		_QMJ deque<bb>qmj_;
	for (auto i : vt_data)
		qmj_.push_back(b);
	,
		i
		)

		time_counter(
			"push_front"
			,
			for (auto i : insert_data)
				std_.push_front(b);
	,
		for (auto i : insert_data)
			qmj_.push_front(b);
	,
		i
		)

		time_counter(
			"access"
			,
			for (auto iter = std_.begin(); iter != std_.end(); ++iter)
				*iter = b;
	,
		for (auto iter = qmj_.begin(); iter != qmj_.end(); ++iter)
			*iter = b;
	,
		i * 2
		)

		time_counter(
			"insert"
			,
			for (int i = 0; i != 100000; ++i)
				std_.insert(std_.begin() + 30, b);
	,
		for (int i = 0; i != 100000; ++i)
			qmj_.insert(qmj_.begin() + 30, b);
	,
		10
		)



	//random_data_product(data_size, vt_data, insert_data)
	//	time_counter(
	//		"push_back"
	//		,
	//		std::deque<int>std_;
	//for (auto i : vt_data)
	//	std_.push_back(i);
	//,
	//	_QMJ deque<int>qmj_;
	//for (auto i : vt_data)
	//	qmj_.push_back(i);
	//,
	//	i
	//	)

	//	time_counter(
	//		"push_front"
	//		,
	//for (auto i : insert_data)
	//	std_.push_front(i);
	//,
	//for (auto i : insert_data)
	//	qmj_.push_front(i);
	//,
	//	i
	//	)

	//	int x = 0;

	//time_counter(
	//	"access"
	//	,
	//	for (auto i : std_)
	//		x ^= i;
	//,
	//	for (auto i : qmj_)
	//		x ^= i;
	//,
	//	i
	//	)

	//	cout << x << endl;

	//	time_counter(
	//		"sort"
	//,
	//	std::sort(std_.begin(), std_.end());
	//,
	//	std::sort(qmj_.begin(), qmj_.end());
	//,
	//	i
	//	)

	//	/*if (equal(qmj_.begin(), qmj_.end(), std_.begin()))
	//		cout << "�ȶ���ȷ" << endl;
	//	else
	//		cout << "�ȶԴ���" << endl;*/

	print_time("deque", "std", "qmj")
}



#endif
