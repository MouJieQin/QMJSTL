#pragma once
#ifndef _HEAP_TEST_
#define _HEAP_TEST_
#include<queue>
#include"heap.h"
#include"queue_qmj.h"
#include"test.h"

void heap_test() {
	std::vector<int>data_size{1000000};

	random_data_product(data_size, vt_data, insert_data)

		for (int j = 0; j != i; ++j)
			vt_data[j] = j;

	std::random_shuffle(vt_data.begin(), vt_data.end());
		time_counter(
			"build_heap"
			,
		std::priority_queue<int>pq_std(vt_data.begin(), vt_data.end());
	,
		_QMJ priority_queue<int>bh(vt_data.begin(), vt_data.end());
	,
		i
		)

		time_counter(
			"push"
			,
			for (auto i : insert_data)
				pq_std.push(i);
	,
		for (auto i : insert_data)
			bh.push(i);
	,
		i
		)

		time_counter(
			"pop"
			,
			while (!pq_std.empty())
			{
				pq_std.pop();
			}
	,
		while (!bh.empty())
		{
			bh.pop();
		}
	,
		2 * i
		)
		
		print_time("priority_queue", "std", "_QMJ binary_heap")

	//random_data_product(data_size, vt_data, insert_data)

	//	time_counter(
	//		"build_heap"
	//		,
	//		std::priority_queue<int>pq_std(vt_data.begin(), vt_data.end());
	//,
	//		_QMJ fib_heap<int>bh(vt_data.begin(), vt_data.end()); 
	//,
	//		i
	//	)

	//	time_counter(
	//		"insert"
	//		,
	//		for (auto i : insert_data)
	//			pq_std.push(i);
	//,
	//		for (auto i : insert_data)
	//			bh.insert(i);
	//,
	//		i
	//		)

	//	time_counter(
	//		"extract_top"
	//		,
	//	while (!pq_std.empty())
	//		pq_std.pop();
	//,	
	//	while (!bh.empty())
	//		bh.extract_top();
	//,
	//	2*i
	//		)

	//print_time("fib","std","_QMJ fib")



	//random_data_product(data_size, vt_data, insert_data)

	//	time_counter(
	//		"build_heap"
	//		,
	//		_QMJ binary_heap<int>pq_std(vt_data.begin(), vt_data.end());
	//,
	//		_QMJ fib_heap<int>fib(vt_data.begin(), vt_data.end()); 
	//,
	//		i
	//	)

	//	time_counter(
	//		"insert",
	//		for (auto i : insert_data)
	//			pq_std.push(i);
	//,
	//			for (auto i : insert_data)
	//				fib.push(i);
	//,
	//				i
	//				)

	//	time_counter(
	//		"pop"
	//		,
	//		while (!pq_std.empty())
	//			pq_std.pop();
	//,
	//			while (!fib.empty())
	//				fib.pop();
	//,
	//				2 * i
	//				)

	//print_time("fib_heap","_QMJ binary_heap","_QMJ fib_heap")
}

#endif
