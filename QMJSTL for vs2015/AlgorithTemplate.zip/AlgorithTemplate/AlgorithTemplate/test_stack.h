#pragma once
#ifndef _TEST_STACK_
#define _TEST_STACK_
#include<stack>
#include"stack_qmj.h"
#include"test.h"
#include"deque_qmj.h"

void test_stack()
{
	std::vector<int>data_size
	{ 0,1,2,3,5,10,100,1000,10000,100000,1000000,10000000};

	random_data_product(data_size, vt_data, insert_data)

		time_counter(
			"push"
			,
			std::stack<int>std_;
			for (auto i : insert_data)
				std_.push(i);
	,
		_QMJ stack<int>qmj_;
		for (auto i : insert_data)
			qmj_.push(i);
	,
		i
		)

		time_counter(
			"pop"
			,
			while (!std_.empty())
				std_.pop();
	,
		while (!qmj_.empty())
			qmj_.pop();
	,
		i
		)

		print_time("stack", "std", "qmj")
}



#endif
