#pragma once
#ifndef _TEST_AVL_TREE_
#define _TEST_AVL_TREE_

#include"test.h"
#include<algorithm>
#include"AVL_tree.h"
#include<set>
#include"set_qmj.h"
#include"vector_qmj.h"
#include<string>

void test_avl()
{
	const int data_size = 1000000;
	qmj::vector<int>vt;
	vt.reserve(data_size);
	for (int i = 0; i != data_size; ++i)
		vt.push_back(i);

	std::random_shuffle(vt.begin(), vt.end());

	typedef decltype(clock())  tim;

	qmj::vector<tim> insert(3), find(3), erase(3);
/////////////////////////////////////////////
	auto start = clock();
	
	std::multiset<int>std_;
	for (auto i : vt)
		std_.insert(i);

	auto end = clock();
	insert[0] = end - start;
////////////////////////////////////////
	start = clock();

	qmj::multiset<int>qmj_;
	for (auto i : vt)
		qmj_.insert(i);

	end = clock();

	insert[1] = end - start;
/////////////////////////////////////////
	start = clock();

	qmj::avl_tree<int>avl;
	for (auto i : vt)
		avl.insert(i);

	end = clock();

	insert[2] = end - start;

	int x = 0;
	/////////////////////////////////////////////
	 start = clock();

	for (auto i : vt)
		x^=*std_.find(i);

	end = clock();
	find[0] = end - start;
	////////////////////////////////////////
	start = clock();

	for (auto i : vt)
		x^=*qmj_.find(i);

	end = clock();

	find[1] = end - start;
	/////////////////////////////////////////
	start = clock();

	for (auto i : vt)
		x ^= avl.find(i)->value;

	end = clock();

	find[2] = end - start;
	/////////////////////////////////////////////

	start = clock();

	for (auto i : vt)
		std_.erase(std_.find(i));

	end = clock();
	erase[0] = end - start;
	////////////////////////////////////////
	start = clock();

	for (auto i : vt)
		qmj_.erase(qmj_.find(i));

	end = clock();

	erase[1] = end - start;
	/////////////////////////////////////////
	start = clock();

	for (auto i : vt)
		avl.erase(avl.find(i));
	 end = clock();

	erase[2] = end - start;

	tim std_t,qmj_t,avl_t;
	std_t = find[0] + erase[0] + insert[0];
	qmj_t = find[1] + erase[1] + insert[1];
	avl_t = find[2] + erase[2] + insert[2];
	qmj::vector<std::string> vs{ "std:mutiset","qmj:multiset","qmj::avl" };
	cout << "data_size: " << data_size << endl;
	cout << "insert:" << endl;
	for (int i = 0; i != 3; ++i)
	{
		cout << vs[i] << ": ";
		cout << insert[i] <<"ms"<< endl;
	}
	cout << endl;

	cout << "find:" << endl;
	for (int i = 0; i != 3; ++i)
	{
		cout << vs[i] << ": ";
		cout << find[i] << "ms" << endl;
	}
	cout << endl;

	cout << "erase:" << endl;
	for (int i = 0; i != 3; ++i)
	{
		cout << vs[i] << ": ";
		cout << erase[i] << "ms" << endl;
	}
	cout << endl;
	cout << "total:" << endl;
	cout << "std::multiset: " << std_t << "ms" << endl;
	cout << "qmj:multiset: " << qmj_t << "ms" << endl;
	cout << "qmj::avl: " << avl_t << "ms" << endl;
	cout << "\n" << endl;

}




#endif
