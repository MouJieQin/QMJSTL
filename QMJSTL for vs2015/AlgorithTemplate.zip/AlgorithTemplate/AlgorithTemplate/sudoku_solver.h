/*
struct TreeNode
{
int val;
TreeNode *left;
TreeNode *right;
TreeNode(int x) : val(x), left(NULL), right(NULL)
{
}
};



struct ListNode
{
int val;
ListNode *next;
ListNode(int x) : val(x), next(NULL)
{
}
};


struct Interval
{
int start;
int end;
Interval() : start(0), end(0)
{
}
Interval(int s, int e) : start(s), end(e)
{
}
};

void print(TreeNode* root)
{
if (root)
{
print(root->left);
std::cout << root->val << " ";
print(root->right);
}
}

struct TreeLinkNode
{
int val;
TreeLinkNode *left, *right, *next;
TreeLinkNode(int x) : val(x), left(NULL), right(NULL), next(NULL)
{
}
};
*/

//class Sudoku_solution
//{
//public:
//	Sudoku_solution(vector<vector<int>>&sudo) :sudoku(sudo)
//		, condidate(9, vector<vector<int>>(9, vector<int>())) {}
//
//	bool operator()()
//	{
//		get_condidate();
//
//		for (int i = 0; i != 9; ++i)
//		{
//			for (int j = 0; j != 9; ++j)
//			{
//				cout << (int)sudoku[i][j] << "\t";
//			}
//			cout << endl;
//		}
//		cout << "\n---------------------------------\n" << endl;
//
//
//		auto f = sudoku_solver();
//		for (int i = 0; i != 9; ++i)
//		{
//			for (int j = 0; j != 9; ++j)
//			{
//				cout << (int)sudoku[i][j] << "\t";
//			}
//			cout << endl;
//		}
//		cout << "\n---------------------------------\n" << endl;
//
//		for (int i = 0; i != 9; ++i)
//		{
//			for (int j = 0; j != 9; ++j)
//			{
//				cout << (int)sudoku[i][j] << "\t";
//			}
//			cout << endl;
//		}
//
//		return f;
//	}
//
//	bool sudoku_solver()
//	{
//		vector<pair<int, int>>stack;
//		for (int i = 0; i != 9; ++i)
//			for (int j = 0; j != 9; ++j)
//				if (!condidate[i][j].empty())
//					stack.push_back({ i,j });
//
//		vector<vector<vector<int>>>tt(condidate);
//		std::sort(stack.begin(), stack.end(),
//			[tt](const pair<int, int>&x, const pair<int, int>&y)
//		{
//			return tt[x.first][x.second].size() < tt[y.first][y.second].size();
//		}
//		);
//		if (!stack.empty())
//		{
//			auto next = stack[0];
//			if (solver_imple(next.first, next.second, stack, 1))
//				return true;
//			return false;
//		}
//		return true;
//	}
//
//	bool solver_imple_recursive(int row, int col,
//		vector<pair<int, int>>&stack, int index)
//	{
//		for (int i = 0; i != condidate[row][col].size(); ++i)
//		{
//			sudoku[row][col] = condidate[row][col][i];
//			if (check(row, col))
//			{
//				if (index == stack.size())
//					return true;
//
//				auto next = stack[index];
//				if (solver_imple_recursive(next.first, next.second, stack, index + 1))
//					return true;
//				else
//					sudoku[row][col] = 0;
//			}
//		}
//		return false;
//	}
//
//	bool solver_imple(int row, int col,
//		vector<pair<int, int>>&stack, int index)
//	{
//		const size_t n = condidate[row][col].size() - 1;
//
//		for (int i = 0; i != n; ++i)
//		{
//			sudoku[row][col] = condidate[row][col][i];
//			if (check(row, col))
//			{
//				if (index == stack.size())
//					return true;
//
//				auto next = stack[index];
//				if (solver_imple_recursive(next.first, next.second, stack, index + 1))
//					return true;
//				else
//					sudoku[row][col] = 0;
//			}
//		}
//		sudoku[row][col] = condidate[row][col].back();
//		vector<vector<vector<int>>>temp(9, vector<vector<int>>(9, vector<int>()));
//		condidate.swap(temp);
//		get_condidate();
//		return sudoku_solver();
//	}
//
//	bool check(int row, int col)
//	{
//
//		vector<int>test_row(10, 0);
//		for (int i = 0; i != 9; ++i)
//		{
//			if (sudoku[row][i] && test_row[sudoku[row][i]])
//			{
//				sudoku[row][col] = 0;
//				return false;
//			}
//			else
//				++test_row[sudoku[row][i]];
//		}
//
//		vector<int>test_col(10, 0);
//		for (int i = 0; i != 9; ++i)
//		{
//			if (sudoku[i][col] && test_col[sudoku[i][col]])
//			{
//				sudoku[row][col] = 0;
//				return false;
//			}
//			else
//				++test_col[sudoku[i][col]];
//		}
//		vector<int>test_gon(10, 0);
//		int x = row / 3 * 3;
//		int y = col / 3 * 3;
//		for (int i = 0; i != 3; ++i)
//			for (int j = 0; j != 3; ++j)
//				if (sudoku[x + i][y + j] && test_gon[sudoku[x + i][y + j]])
//				{
//					sudoku[row][col] = 0;
//					return false;
//				}
//				else
//					++test_gon[sudoku[x + i][y + j]];
//		return true;
//	}
//
//	void get_condidate()
//	{
//		for (int i = 0; i != 9; ++i)
//		{
//			for (int j = 0; j != 9; ++j)
//			{
//				if (!sudoku[i][j])
//					get_condidate_imple(i, j);
//			}
//		}
//	}
//
//	void get_condidate_imple(int row, int col)
//	{
//
//		vector<int>test_v(10, 0);
//		for (int i = 0; i != 9; ++i)
//		{
//			++test_v[sudoku[row][i]];
//			++test_v[sudoku[i][col]];
//		}
//		int x = row / 3 * 3;
//		int y = col / 3 * 3;
//		for (int i = 0; i != 3; ++i)
//			for (int j = 0; j != 3; ++j)
//				++test_v[sudoku[x + i][y + j]];
//
//		for (int i = 1; i != 10; ++i)
//			if (!test_v[i])
//				condidate[row][col].push_back(i);
//
//		bool flag = false;
//		for (int i = 0; i != 9; ++i)
//			for (int j = 0; j != 9; ++j)
//			{
//				if (condidate[i][j].size() == 1)
//				{
//					flag = true;
//					sudoku[i][j] = condidate[i][j][0];
//				}
//			}
//		if (flag)
//		{
//			vector<vector<vector<int>>>temp(9, vector<vector<int>>(9, vector<int>()));
//			condidate.swap(temp);
//			get_condidate();
//		}
//	}
//
//private:
//	vector<vector<int>>sudoku;
//	vector<vector<vector<int>>>condidate;
//};
//
//
//
//int main()
//{
//	vector<vector<int>>sodu
//	{
//		/*{5,3,0,0,7,0,0,0,0},
//		{6,0,0,1,9,5,0,0,0},
//		{0,9,8,0,0,0,0,6,0},
//		{8,0,0,0,6,0,0,0,3},
//		{4,0,0,8,0,3,0,0,1},
//		{7,0,0,0,2,0,0,0,6},
//		{0,6,0,0,0,0,2,8,0},
//		{0,0,0,4,1,9,0,0,5},
//		{0,0,0,0,8,0,0,7,9}*/
//
//		//{8,0,0,0,0,0,0,0,0},
//		//{0,0,3,6,0,0,0,0,0},
//		//{0,7,0,0,9,0,2,0,0},
//		//{0,5,0,0,0,7,0,0,0},
//		//{0,0,0,0,4,0,7,0,0},
//		//{0,0,0,1,0,5,0,3,0},
//		//{0,0,1,0,0,0,0,6,8},
//		//{0,0,8,5,0,0,0,1,0},
//		//{0,9,0,0,0,0,4,0,0}
//
//
//		//{0,0,5,3,0,0,0,0,0},
//		//{8,0,0,0,0,0,0,2,0},
//		//{0,7,0,0,1,0,5,0,0},
//		//{4,0,0,0,0,5,3,0,0},
//		//{0,1,0,0,7,0,0,0,6},
//		//{0,0,3,2,0,0,0,8,0},
//		//{0,6,0,5,0,0,0,0,9},
//		//{0,0,4,0,0,0,0,3,0},
//		//{0,0,0,0,0,9,7,0,0}
//
//		/*{0,0,0,7,0,0,0,0,2},
//		{0,5,8,0,0,0,0,0,0},
//		{0,3,0,0,0,0,4,0,0},
//		{0,0,0,0,0,0,3,5,0},
//		{7,0,0,6,2,0,0,0,0},
//		{0,0,0,0,0,0,8,0,0},
//		{6,0,0,0,4,0,0,0,1},
//		{0,0,0,0,0,5,0,0,0},
//		{0,0,0,2,0,0,0,0,0}*/
//
//
//		//{0,6,0,2,0,5,0,1,0},
//		//{7,0,0,0,0,0,3,0,0},
//		//{4,0,0,0,0,0,0,0,0},
//		//{9,0,0,0,7,0,0,0,0},
//		//{0,0,0,0,0,0,0,0,0},
//		//{0,1,0,0,0,0,0,2,5},
//		//{0,0,0,0,0,0,4,0,0},
//		//{0,2,0,1,0,0,0,0,0},
//		//{0,0,0,0,9,0,7,0,0},
//
//		{ 0,0,0,0,9,6,0,0,0 },
//		{ 5,0,0,0,0,0,4,0,0 },
//		{ 0,0,1,0,7,0,0,0,0 },
//		{ 0,0,9,0,0,0,0,0,0 },
//		{ 0,0,7,2,0,0,0,0,0 },
//		{ 0,0,0,3,0,0,5,0,4 },
//		{ 0,0,0,0,0,0,0,0,0 },
//		{ 4,0,0,1,5,0,0,0,0 },
//		{ 0,0,6,0,0,0,0,9,0 },
//
//	};
//	//vector<vector<int>>s(9);
//	//int c;
//	//for (size_t i = 0; i != 9; ++i)
//	//	for (size_t j = 0; j != 9; ++j)
//	//	{
//	//		cin >> c;
//	//		s[i].push_back(c);
//	//	}
//
//	//Sudoku_solution solver(sodu);
//	//if (solver())
//	//	cout << "Yes" << endl;
//	//else
//	//	cout << "No" << endl; #pragma once







/*

#pragma once
#ifndef _RB_TREE_
#define _RB_TREE_
#include<utility>
#include"iterator_qmj.h"
#include"allocator.h"

namespace qmj
{
typedef bool rbt_color_type;
constexpr rbt_color_type rbt_red = false;
constexpr rbt_color_type rbt_black = true;

template<typename value_type>
struct rb_tree_node;

template<typename value_type>
struct rb_tree_base_node
{
typedef rb_tree_node<value_type>* link_type;

rb_tree_base_node(
rbt_color_type color = rbt_red,
link_type p = nullptr,
link_type left = nullptr,
link_type right = nullptr) :
color(color), p(p), left(left), right(right)
{
}

rbt_color_type color;
link_type p;
link_type left;
link_type right;
};

template<typename value_type>
struct rb_tree_node :
public rb_tree_base_node<value_type>
{
typedef rb_tree_node<value_type>* link_type;
typedef rb_tree_base_node<value_type> base_node_type;

rb_tree_node(const value_type&val) :
value(val)
{
}

rb_tree_node(
rbt_color_type color = rbt_red,
link_type p = nullptr,
link_type left = nullptr,
link_type right = nullptr) :
base_node_type(color, p, left, right), value()
{
}

rb_tree_node(
const value_type&value,
rbt_color_type color = rbt_red,
link_type p = nullptr,
link_type left = nullptr,
link_type right = nullptr) :
base_node_type(color, p, left, right), value(value)
{
}

value_type value;

static link_type minimum(link_type rt)
{
while (rt->left->left)
rt = rt->left;
return rt;
}

static link_type maximum(link_type rt)
{
while (rt->right->right)
rt = rt->right;
return rt;
}
};

template<typename value_type>
struct rb_tree_const_iterator
{
template<typename key_type, typename value_type,
typename keyOfValue, typename Compare, typename Alloc>
friend class rb_tree;

typedef std::bidirectional_iterator_tag iterator_category;
typedef value_type value_type;
typedef const value_type& reference;
typedef const value_type* pointer;
typedef ptrdiff_t difference_type;

typedef rb_tree_node<value_type> node_type;
typedef rb_tree_node<value_type>* link_type;
typedef rb_tree_const_iterator<value_type>self;

rb_tree_const_iterator() :
node(nullptr)
{
}

rb_tree_const_iterator(link_type node) :
node(node)
{
}

rb_tree_const_iterator(const self&x) :
node(x.node)
{
}

bool operator==(const self&x)const
{
return node == x.node;
}

bool operator!=(const self&x)const
{
return (!(operator==(x)));
}

reference operator*()const
{
return (node->value);
}

pointer operator->()const
{
return (&(operator*()));
}

self& operator=(const self&x)
{
node = x.node;
return (*this);
}

self& operator--()
{
if (!(node->left))//this is end(),node=nil
node = node_type::maximum(node->p);
else if (node->left->left)//node have a left node that not nil
node = node_type::maximum(node->left);
else
{//node have a left node is nil
while (node->p->p&&node->p->left == node)
node = node->p;
node = node->p;
}
return *this;
}

self operator--(int)
{
auto temp = *this;
operator--();
return temp;
}

self& operator++()
{
if (node->right->right)
node = node_type::minimum(node->right);
else
{
while (node->p->p&&node->p->right == node)
node = node->p;
node = node->p;
}
return *this;
}

self operator++(int)
{
auto temp = *this;
operator++();
return temp;
}
protected:
link_type get_node()
{
return (node);
}

protected:
link_type node;
};

template<typename value_type>
struct rb_tree_iterator :
public rb_tree_const_iterator<value_type>
{
typedef std::bidirectional_iterator_tag iterator_category;
typedef value_type value_type;
typedef value_type& reference;
typedef value_type* pointer;
typedef ptrdiff_t difference_type;

typedef rb_tree_const_iterator<value_type> base_iterator;
typedef typename base_iterator::node_type node_type;
typedef typename base_iterator::link_type link_type;
typedef rb_tree_iterator<value_type>self;

rb_tree_iterator() :
base_iterator()
{
}

rb_tree_iterator(link_type node) :
base_iterator(node)
{
}

rb_tree_iterator(const self&x) :
base_iterator(x.node)
{
}

reference operator*()const
{
return (node->value);
}

pointer operator->()const
{
return (&(operator*()));
}

self& operator=(const self&x)
{
node = x.node;
return (*this);
}

self& operator--()
{
if (!(node->left))//this is end(),node=nil
node = node_type::maximum(node->p);
else if (node->left->left)//node have a left node that not nil
node = node_type::maximum(node->left);
else
{//node have a left node is nil
while (node->p->p&&node->p->left == node)
node = node->p;
node = node->p;
}
return *this;
}

self operator--(int)
{
auto temp = *this;
operator--();
return temp;
}

self& operator++()
{
if (node->right->right)
node = node_type::minimum(node->right);
else
{
while (node->p->p&&node->p->right == node)
node = node->p;
node = node->p;
}
return *this;
}

self operator++(int)
{
auto temp = *this;
operator++();
return temp;
}
};

template<typename key_type,
typename value_type,
typename keyOfValue,
typename Compare = std::less<key_type>,
typename Alloc = _QMJ allocator<value_type>>
class rb_tree
{
public:
typedef key_type key_type;
typedef value_type value_type;
typedef keyOfValue get_key;
typedef size_t size_type;
typedef Alloc allocator_type;
typedef value_type* pointer;
typedef const value_type* const_pointer;
typedef value_type& reference;
typedef const value_type& const_reference;
typedef ptrdiff_t difference_type;
typedef _QMJ allocator<rb_tree_node<value_type>> alloc;
typedef Alloc allocator_type;

typedef rb_tree_iterator<value_type> iterator;
typedef rb_tree_const_iterator<value_type> const_iterator;
typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
typedef std::reverse_iterator<iterator> reverse_iterator;

typedef rb_tree_node<value_type> node_type;
typedef rb_tree_base_node<value_type> base_node_type;
typedef rb_tree_node<value_type>* link_type;
typedef rb_tree_base_node<value_type>* base_link_type;
typedef std::pair<iterator, bool>pairib;
typedef rb_tree<key_type, value_type, keyOfValue, Compare, Alloc> self;

rb_tree() :
nil(create_nil()), root(nil),
comp(), node_count(0)
{
}

explicit rb_tree(Compare comp) :
nil(create_nil()),
root(nil), comp(comp), node_count(0)
{
}

rb_tree(const self&x) :
nil(create_nil()),
root(nil), comp(x.comp), node_count(0)
{
root = copy_assign(root, x.get_root(), x.get_nil());
nil->p = root;
node_count = x.node_count;
}

rb_tree(self&&x) :
nil(x.nil), root(x.root),
comp(x.comp), node_count(x.node_count)
{
nil = root = nullptr;
node_count = 0;
}

self& operator=(self x)
{
swap(x);
return *this;
}

~rb_tree()
{
rbt_destroy(get_root());
destroy_nil();
}

bool operator==(const self&x)const/////////////////////////////
{
if (size() != x.size())
return false;
auto first1 = begin();
auto last1 = end();
auto first2 = x.begin();
for (; first1 != last1; ++first1, ++first2)
if (!(std::equal_to<value_type>()(*first1, *first2)))
return false;
return true;
}

bool operator!=(const self&x)const////////////////////////////
{
return !(operator==(x));
}

void print_rbt()
{
print(get_root());
}//������

iterator end()
{
return iterator(nil);
}

iterator begin()
{
return root == nil ? end() : iterator(minimum(get_root()));
}

const_iterator end()const
{
return const_iterator(nil);
}

const_iterator begin()const
{
return root == nil ? end() : const_iterator(minimum(get_root()));
}

const_iterator cend()const
{
return const_iterator(nil);
}

const_iterator cbegin()const
{
return root == nil ? cend() : const_iterator(minimum(get_root()));
}

reverse_iterator rbegin()
{
return reverse_iterator(end());
}

reverse_iterator rend()
{
return reverse_iterator(begin());
}

const_reverse_iterator rbeing()const
{
return const_reverse_iterator(end());
}

const_reverse_iterator rend()const
{
return const_reverse_iterator(begin());
}

const_reverse_iterator crbegin()const
{
return const_reverse_iterator(cend());
}

const_reverse_iterator crend()const
{
return const_reverse_iterator(cbegin());
}

void clear()
{
rbt_destroy(get_root());
root = nil;
node_count = 0;
}

void swap(self&x)noexcept
{
std::swap(nil, x.nil);
std::swap(root, x.root);
std::swap(comp, x.comp);
std::swap(node_count, x.node_count);
}

size_type size()const
{
return node_count;
}

iterator erase(iterator& x)
{
auto temp = x;
auto pred = ++temp;
rbt_delete(x.node);
return temp;
}

size_type erase(const key_type&k)
{
size_type count = 0;
iterator first, last;
std::tie(first, last) = equal_range(k);
for (; first != last; ++count)
erase(first++);
return (count);
}

iterator erase(iterator& first, iterator& last)
{
for (; first != last;)
erase(first++);
return (last);
}

void delete_key(const key_type&key)
{
rbt_delete(find(key).node);
}

const_iterator lower_bound_imple(const key_type&key)const;

const_iterator lower_bound(const key_type&key)const
{
return lower_bound_imple(key);
}

iterator lower_bound(const key_type&key)
{
return (iterator&)lower_bound_imple(key);
}

const_iterator upper_bound_imple(const key_type&key)const;

const_iterator upper_bound(const key_type&key)const
{
return upper_bound_imple(key);
}

iterator upper_bound(const key_type&key)
{
return (iterator&)upper_bound_imple(key);
}

std::pair<const_iterator, const_iterator>
equal_range(const key_type&key)const
{
return{ lower_bound(key),upper_bound(key) };
}

std::pair<iterator, iterator> equal_range(const key_type&key)
{
return{ lower_bound(key),upper_bound(key) };
}

const_iterator find_imple(const key_type&key)const;

const_iterator find(const key_type&key)const
{//may not first inserted element
return find_imple(key);
}

iterator find(const key_type&key)
{//may not first inserted element
return (iterator&)find_imple(key);
}

iterator insert_equal(const value_type& value);

template<typename InputIterator>
void insert_equal(InputIterator first,
InputIterator last)
{
while (first != last)
insert_equal(*first++);
}

std::pair<iterator, bool>
insert_unique(const value_type& value);

template<typename InputIterator>
void insert_unique(InputIterator first,
InputIterator last)
{
while (first != last)
insert_unique(*first++);
}

//template<typename...types>
//iterator emplace(iterator pos, types&&...args)
//{

//	link_type tar = create_node(rbt_red, par, nil, nil);
//	construct_value(tar, std::forward(args)...);


//}

protected:


	protected:
		void print(link_type rt, int counter_hight = 0)//������
		{
			if (rt != nil)
			{
				print(rt->right, counter_hight + 1);
				for (auto n = counter_hight; n != -1; --n)
					cout << "\t";
				cout << rt->value;
				rt->color ? cout << "|��" << endl : cout << "|��" << endl;
				print(rt->left, counter_hight + 1);
				cout << endl;
			}
		}

	protected:

		template<typename...types>
		link_type create_node(types&&...args)
		{
			link_type ptr = alloc::allocate();
			alloc::construct(ptr, std::forward<types>(args)...);
			return ptr;
		}

		template<typename...types>
		void construct_value(link_type ptr, types&&...args)
		{
			allocator_type::construct((&(ptr->value)), std::forward<types>(args)...);
		}

		void destroy_and_free_node(link_type node)
		{
			allocator_type::destroy((&(node->value)));
			alloc::destroy(node);
		}

		void rbt_delete(link_type tar);

		link_type get_root()const
		{
			return (root);
		}

		link_type get_nil()const
		{
			return (nil);
		}

		link_type create_nil()const
		{
			link_type ptr = (link_type)std::malloc(sizeof(base_node_type));
			_QMJ allocator<base_node_type>::construct(ptr, rbt_black);
			return ptr;
		}

		void destroy_nil()const
		{
			std::free(nil);
		}

		static link_type minimum(link_type rt)
		{
			return node_type::minimum(rt);
		}

		static link_type maximum(link_type rt)
		{
			return node_type::maximum(rt);
		}

		void rbt_left_rotate(link_type x);

		void rbt_right_rotate(link_type x);

		void rbt_destroy(link_type x);

		void rbt_delete_fixup(link_type x);

		iterator rbt_insert_fixup(link_type tar);

		link_type copy_assign(link_type par, const link_type cur, const link_type nl)
		{
			if (cur != nl)
			{
				link_type my = create_node(cur->color, par);
				construct_value(my, cur->value);
				my->left = copy_assign(my, cur->left, nl);
				my->right = copy_assign(my, cur->right, nl);
				return my;
			}
			return nil;
		}

		void rbt_transplant(link_type lhs, link_type rhs)
		{
			if (lhs->p == nil)
				root = rhs;
			else if (lhs == lhs->p->left)
				lhs->p->left = rhs;
			else
				lhs->p->right = rhs;
			rhs->p = lhs->p;
		}

		iterator insert_imple(link_type par, link_type tar);

	private:
		link_type nil;
		link_type root;
		size_type node_count;
		Compare comp;
	};

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	void rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		rbt_destroy(link_type x)
	{
		if (x != nil)
		{
			rbt_destroy(x->left);
			rbt_destroy(x->right);
			destroy_and_free_node(x);
		}
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::const_iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		lower_bound_imple(const key_type&key)const
	{
		auto cur = get_root();
		auto result = cur;
		while (cur != nil)
		{
			result = cur;
			if (comp(get_key()(cur->value), key))
				cur = cur->right;
			else
				cur = cur->left;
		}
		if (result == nil)
			return cend();
		else if (comp(get_key()(result->value), key))
			return ++const_iterator(result);
		else
			return const_iterator(result);
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::const_iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		upper_bound_imple(const key_type&key)const
	{
		link_type cur = get_root();
		link_type result = cur;
		while (cur != nil)
		{
			result = cur;
			if (comp(key, get_key()(cur->value)))
				cur = cur->left;
			else
				cur = cur->right;
		}
		if (result == nil)
			return cend();
		else if (comp(key, get_key()(result->value)))
			return const_iterator(result);
		else
			return ++const_iterator(result);
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::const_iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		find_imple(const key_type&key)const
	{
		auto cur = get_root();
		while (cur != nil)
		{
			if (comp(key, get_key()(cur->value)))
				cur = cur->left;
			else if (comp(get_key()(cur->value), key))
				cur = cur->right;
			else
				return const_iterator(cur);
		}
		return cend();
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		insert_equal(const value_type& value)
	{
		auto cur = get_root();
		auto par = nil;
		while (cur != nil)
		{
			par = cur;
			cur = comp(get_key()(value), get_key()(par->value)) ? par->left : par->right;
		}
		link_type tar = create_node(rbt_red, par, nil, nil);
		construct_value(tar, value);
		return insert_imple(par, tar);
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	std::pair<typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::iterator, bool>
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		insert_unique(const value_type& value)
	{
		link_type cur = get_root();
		link_type par = nil;
		while (cur != nil)
		{
			par = cur;
			if (comp(get_key()(value), get_key()(cur->value)))
				cur = cur->left;
			else if (comp(get_key()(cur->value), get_key()(value)))
				cur = cur->right;
			else
				return
				std::pair<iterator, bool>(iterator(cur), false);
		}
		link_type tar = create_node(rbt_red, par, nil, nil);
		construct_value(tar, value);
		return{ insert_imple(par, tar),true };
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		insert_imple(link_type par, link_type tar)
	{
		if (par == nil)
			root = tar;
		else if (comp(get_key()(tar->value), get_key()(par->value)))
			par->left = tar;
		else
			par->right = tar;
		return
			rbt_insert_fixup(tar);
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	typename rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::iterator
		rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		rbt_insert_fixup(link_type tar)
	{
		iterator iter = iterator(tar);
		while (!tar->p->color)
		{
			auto grandpar = tar->p->p;
			if (tar->p == grandpar->left)
			{
				if (!grandpar->right->color)
				{
					grandpar->left->color = rbt_black;
					grandpar->right->color = rbt_black;
					grandpar->color = rbt_red;
					tar = grandpar;
				}
				else
				{
					if (tar == tar->p->right)
					{
						rbt_left_rotate(tar->p);
						tar = tar->left;
					}
					grandpar->color = rbt_red;
					grandpar->left->color = rbt_black;
					rbt_right_rotate(grandpar);
				}
			}
			else
			{
				if (!grandpar->left->color)
				{
					grandpar->right->color = rbt_black;
					grandpar->left->color = rbt_black;
					grandpar->color = rbt_red;
					tar = grandpar;
				}
				else
				{
					if (tar == tar->p->left)
					{
						rbt_right_rotate(tar->p);
						tar = tar->right;
					}
					grandpar->color = rbt_red;
					grandpar->right->color = rbt_black;
					rbt_left_rotate(grandpar);
				}
			}
		}
		root->color = rbt_black;
		++node_count;
		nil->p = root;
		return iter;
	}


	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	void rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		rbt_delete(link_type tar)
	{//ɾ���ڵ�
		if (tar == nil)
			return;
		link_type y = tar;
		rbt_color_type y_original_color = y->color;
		link_type x;
		if (tar->left == nil)
		{
			x = tar->right;
			rbt_transplant(tar, x);
		}
		else if (tar->right == nil)
		{
			x = tar->left;
			rbt_transplant(tar, x);
		}
		else
		{
			y = minimum(tar->right);
			y_original_color = y->color;
			x = y->right;
			if (y->p == tar)
				x->p = y;//��x���ڱ�ʱΪɾ����׼��
			else
			{
				rbt_transplant(y, x);
				y->right = tar->right;
				y->right->p = y;
			}
			rbt_transplant(tar, y);
			y->left = tar->left;
			y->left->p = y;
			y->color = tar->color;
		}

		--node_count;
		if (y_original_color)
			rbt_delete_fixup(x);
		destroy_and_free_node(tar);
		nil->p = root;
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	void rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		rbt_delete_fixup(link_type x)
	{
		while (x != root&&x->color)
		{
			if (x == x->p->left)
			{
				link_type w = x->p->right;
				if (!w->color)
				{//���1������ֵܽڵ��Ǻ�ɫ
					x->p->color = rbt_red;
					w->color = rbt_black;
					rbt_left_rotate(x->p);
					w = x->p->right;
				}

				if (w->right->color&&w->left->color)
				{//��������ֵܽڵ�������ӽڵ㶼�Ǻ�ɫ
					w->color = rbt_red;
					x = x->p;
				}
				else if (w->right->color)
				{//�ֵܽڵ����ڵ�Ϊ��ɫ
					w->color = rbt_red;
					w->left->color = rbt_black;
					rbt_right_rotate(w);
					w = x->p->right;
				}
				if (!w->right->color)
				{//�ֵܽڵ���ҽڵ�Ϊ��ɫ
					w->color = x->p->color;
					x->p->color = rbt_black;
					w->right->color = rbt_black;
					rbt_left_rotate(x->p);
					x = root;
				}
			}
			else
			{
				link_type  w = x->p->left;
				if (!w->color)
				{
					x->p->color = rbt_red;
					w->color = rbt_black;
					rbt_right_rotate(x->p);
					w = x->p->left;
				}
				if (w->right->color&&w->left->color)
				{
					w->color = rbt_red;
					x = x->p;
				}
				else if (w->left->color)
				{
					w->color = rbt_red;
					w->right->color = rbt_black;
					rbt_left_rotate(w);
					w = x->p->left;
				}
				if (!w->left->color)
				{
					w->color = x->p->color;
					x->p->color = rbt_black;
					w->left->color = rbt_black;
					rbt_right_rotate(x->p);
					x = root;
				}
			}
		}
		x->color = rbt_black;
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	void rb_tree<key_type, value_type, keyOfValue, Compare, Alloc> ::
		rbt_left_rotate(link_type x)
	{//����
		auto xRight = x->right;
		xRight->p = x->p;

		if (xRight->left != nil)
			xRight->left->p = x;
		x->right = xRight->left;

		if (x->p == nil)
			root = xRight;
		else if (x->p->left == x)
			x->p->left = xRight;
		else
			x->p->right = xRight;
		xRight->left = x;
		x->p = xRight;
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>
	void rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>::
		rbt_right_rotate(link_type x)
	{//����
		auto xLeft = x->left;
		xLeft->p = x->p;

		if (xLeft->right != nil)
			xLeft->right->p = x;
		x->left = xLeft->right;

		if (x->p == nil)
			root = xLeft;
		else if (x->p->left == x)
			x->p->left = xLeft;
		else
			x->p->right = xLeft;
		xLeft->right = x;
		x->p = xLeft;
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator==(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return (left.size() == right.size()
			&& std::equal(left.begin(), right.end()));
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator!=(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return (!(left == right));
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator<(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return std::lexicographical_compare
		(left.begin(), left.end(), right.begin(), right.end());
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator>(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return (right < left);
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator<=(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return (!(right < left));
	}

	template<typename key_type, typename value_type, typename keyOfValue, typename Compare, typename Alloc>inline
		bool operator>=(const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&left,
			const rb_tree<key_type, value_type, keyOfValue, Compare, Alloc>&right)
	{
		return (!(left < right));
	}

}

#endif



*/