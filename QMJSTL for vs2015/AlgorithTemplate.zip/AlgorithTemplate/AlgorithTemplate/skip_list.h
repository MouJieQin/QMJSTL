#pragma once
#ifndef _SKIP_LIST_
#define _SKIP_LIST_
#include"allocator.h"

namespace qmj
{
	template<typename value_type>
	struct skip_list_node;

	template<typename value_type>
	struct skip_list_node_base
	{
		typedef skip_list_node<value_type>* link_type;

		skip_list_node_base(link_type right = nullptr,
			link_type down = nullptr) :
			right(right), down(down)
		{
		}

		link_type right;
		link_type down;
	};

	template<typename value_type>
	struct skip_list_node :
		public skip_list_node_base<value_type>
	{
		typedef skip_list_node<value_type>* link_type;
		typedef skip_list_node_base<value_type> base_type;

		skip_list_node(link_type right = nullptr,
			link_type down = nullptr) :
			value(), base_type(right, down)
		{
		}

		skip_list_node(const value_type&value,
			link_type right = nullptr,
			link_type down = nullptr) :
			value(value), base_type(right, down)
		{
		}

		skip_list_node(value_type&&value,
			link_type right = nullptr,
			link_type down = nullptr) :
			value(std::move(value)),
			base_type(right, down)
		{
		}

		value_type value;
	};

	template<typename value_type,
		value_type inf>
		class skip_list
	{
	public:
		typedef skip_list_node<value_type> node_type;
		typedef node_type* link_type;

		typedef qmj::allocator<skip_list_node<value_type>> alloc;

		skip_list()
		{
			init();
		}

		link_type find(const value_type&val)
		{
			return (find_imple(val));
		}

		link_type insert(const value_type&val)
		{
			return (insert_equal(val));
		}
	private:
		template<typename...types>
		link_type create_node(types&&...args)
		{
			link_type node = alloc::allocate();
			alloc::construct(node, std::forward<types>(args)...);
			return (node);
		}

		void destroy_and_free_node(link_type node)
		{
			qmj::allocator<value_type>::destroy(&(node->value));
			alloc::deallocate(node);
		}

		void init()
		{
			bottom = alloc::allocate();
			alloc::construct(bottom, bottom, bottom);
			tail = alloc::allocate();
			alloc::construct(tail, inf, tail);
			header = alloc::allocate();
			alloc::construct(header, inf, tail, bottom);
		}

		link_type find_imple(const value_type&val)
		{
			link_type cur = header;
			for (bottom->value = val;;)
				if (val < cur->value)
					cur = cur->down;
				else if (cur->value < val)
					cur = cur->right;
				else
					break;
			return (cur);
		}

		template<typename value_type>
		link_type insert_equal(value_type&&val)
		{
			link_type cur = header;
			for (bottom->value = val; cur != bottom;)
			{
				while (cur->value < val)
					cur = cur->right;
				if (cur->down->right->right->value
					< cur->value)
				{
					link_type new_node = create_node(
						cur->value, cur->right,
						cur->down->right->right);
					cur->right = new_node;
					cur->value = cur->down->right->value;
				}
				else
					cur = cur->down;
			}

			if (header->right != tail)
			{
				link_type new_node = create_node(inf, tail, header);
				header = new_node;
			}
			return (header);
		}

	private:
		link_type header;
		link_type bottom;
		link_type tail;
	};

}

#endif
