#pragma once
//#ifndef _B_TREE_
//#define _B_TREE_
//#include<vector>
////ɾ����bug
//namespace qmj
//{
//	template<typename key_type>
//	struct b_tree_node_qmj {
//		typedef key_type key_type;
//		typedef b_tree_node_qmj<key_type>* link_type;
//
//		b_tree_node_qmj():n(0),leaf(true){}
//		~b_tree_node_qmj() 
//		{ 
//			std::vector<key_type>().swap(key);
//			std::vector<link_type>().swap(c);
//		}
//		size_t n;
//		bool leaf;
//		std::vector<key_type>key;
//		std::vector<link_type>c;
//	};
//
//	template<typename key_type,typename Compare=std::less<key_type>>
//	class b_tree_qmj 
//	{
//	public:
//		typedef key_type key_type;
//		typedef b_tree_node_qmj<key_type>* link_type;
//
//		b_tree_qmj(size_t t = 2) :t(t),root(nullptr),comp(Compare()),node_count(0) {}
//		~b_tree_qmj() { destroy_b_tree(get_root()); }
//
//		void b_tree_insert(const key_type& k);
//		void b_tree_delete(const key_type&k)
//		{
//			b_tree_delete_imple(get_root(), k);
//			--node_count;
//		}
//		size_t size() { return node_count; }
//		bool empty() { return !node_count; }
//
//		link_type get_root() { return root; }
//
//	public:
//		link_type maxiumn(link_type rt)
//		{//���ؽ��ܸ��ڵ�����ֵ����
//			if (rt->leaf)
//				return rt;
//			else
//				return maxiumn(rt->c.back());
//		}
//
//		link_type miniumn(link_type rt)
//		{
//			if (rt->leaf)
//				return rt;
//			else
//				return miniumn(rt->c.front());
//		}
//
//		void print_bt() { print(get_root()); }
//		void print(link_type rt, size_t counter = 0)
//		{
//			if (rt)
//			{
//				for (size_t i = rt->n; i != -1 && i > rt->n / 2; --i)
//					if (rt->c.size() > i)
//					{
//						print(rt->c[i], counter + 1);
//						cout << endl;
//					}
//				for (size_t n = counter; n != -1; --n)
//					cout << "\t";
//				for (size_t i = 0; i < rt->key.size(); ++i)
//					cout << static_cast<char>(rt->key[i]);
//						cout << rt->key.size() << "|" << rt->c.size() << "|" << rt->n << endl;
//				cout << endl;
//
//				for (size_t i = rt->n / 2; i != -1; --i)
//					if (rt->c.size() > i)
//					{
//						print(rt->c[i], counter + 1);
//						cout << endl;
//					}
//			}
//		}
//
//	protected:
//		void b_tree_spilt_child(link_type x, size_t i);
//		void b_tree_insert_nonfull(link_type rt, const key_type& k);
//		void b_tree_delete_imple(link_type rt, const key_type& k);
//		void b_tree_merge(link_type rt, size_t i);
//		void left_replace(link_type rt, size_t i);
//		void right_replace(link_type rt, size_t i);
//		void destroy_b_tree(link_type rt)
//		{
//			if (rt)
//			{
//				for (size_t i = rt->n; i != -1 && i > rt->n / 2; --i)
//					if (rt->c.size() > i)
//						destroy_b_tree(rt->c[i]);
//				for (size_t i = rt->n / 2; i != -1; --i)
//					if (rt->c.size() > i)
//						destroy_b_tree(rt->c[i]);
//				delete rt;
//			}
//		}
//	private:
//		size_t t;
//		link_type root;
//		Compare comp;
//		size_t node_count;
//	};
//
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		b_tree_insert(const key_type& k)
//	{
//		auto rt = root;
//		if (!root)
//		{
//			auto t = new b_tree_node_qmj<key_type>;
//			root = t;
//			t->key.push_back(k);
//			t->n = 1;
//			t->leaf = true;
//			return;
//		}
//		if (rt->n == 2 * t - 1)
//		{
//			auto t = new b_tree_node_qmj<key_type>;
//			root = t;
//			t->n = 0;
//			t->leaf = false;
//			t->c.push_back(rt);
//			b_tree_spilt_child(t, 0);
//			b_tree_insert_nonfull(t, k);
//		}
//		else
//			b_tree_insert_nonfull(rt, k);
//		++node_count;
//	}
//
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type,Compare>:: 
//		b_tree_spilt_child(link_type x, size_t i)
//	{
//		auto y = x->c[i];
//
//		x->key.resize(x->n + 1);
//		for (size_t j = x->n - 1; j >= i&&j != -1; --j)
//			x->key[j + 1] = x->key[j];
//		x->key[i] = y->key[t - 1];
//
//		auto z = new b_tree_node_qmj<key_type>;
//		z->n = t - 1;
//		z->leaf = y->leaf;
//		z->key.resize(t - 1);
//		for (size_t j = 0; j < t - 1; ++j)
//			z->key[j] = y->key[j + t];
//
//		if (!y->leaf)
//		{
//			z->c.resize(t);
//			for (size_t j = 0; j < t; ++j)
//				z->c[j] = y->c[j + t];
//			y->c.resize(t);
//		}
//
//		y->key.resize(t - 1);
//		y->n = t - 1;
//
//		x->c.resize(x->n + 2);
//		for (size_t j = x->n; j > i&&j != -1; --j)
//			x->c[j + 1] = x->c[j];
//		x->c[i + 1] = z;
//		x->n += 1;
//	}
//
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		b_tree_insert_nonfull(link_type rt, const key_type& k)
//	{
//		size_t i = rt->n - 1;
//		if (rt->leaf)
//		{
//			rt->n += 1;
//			rt->key.resize(rt->n);
//			while (i != -1 && comp(k, rt->key[i]))
//			{
//				rt->key[i + 1] = rt->key[i];
//				--i;
//			}
//			rt->key[i + 1] = k;
//		}
//		else {
//			while (i != -1 && comp(k, rt->key[i]))
//				--i;
//			i += 1;
//			if (rt->c[i]->n == 2 * t - 1)
//			{
//				b_tree_spilt_child(rt, i);
//				if (comp(rt->key[i], k))
//					i += 1;
//			}
//			b_tree_insert_nonfull(rt->c[i], k);
//		}
//	}
//
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		b_tree_delete_imple(link_type rt, const key_type& k)
//	{
//		if (!rt)
//			return;
//		if (rt == root && (!rt->n)) {
//			if (rt->c.empty())//�����ѿ�
//				return;
//			root = rt->c[0];
//			rt = root;
//		}
//		size_t i = rt->n - 1;
//		while (i != -1 && comp(k,rt->key[i]))//�ҵ�������k���±�
//			--i;
//
//		if (rt->leaf && (i == -1 || rt->key[i] != k))//�ؼ��ֲ�������
//			return;
//
//		if (i !=-1 && rt->key[i] == k)
//		{//�ýڵ㺬�йؼ���
//			if (rt->leaf)
//			{//Ҷ�ڵ�ֱ��ɾ������Ϊ�ݹ�Ĺ�ϵ��Ҷ�ڵ��nһ������t-1
//				for (size_t j = i; j < rt->n - 1; ++j)
//					rt->key[j] = rt->key[j + 1];
//				rt->n -= 1;
//				rt->key.resize(rt->n);
//			}
//			else
//			{//�ؼ������ڲ��ڵ�		
//				if (rt->c[i]->n > t - 1)
//				{//ǰһ���ڵ��n����t-1���ҵ��ùؼ��ֵ�ǰ�������ݹ�ɾ����ǰ��һ����Ҷ�ڵ���
//					auto pre = maxiumn(rt->c[i]);//��ǰ������ؼ��֣����ͬ��
//					auto pre_key = pre->key.back();
//					b_tree_delete_imple(root, pre_key);
//					rt->key[i] = pre_key;
//				}
//				else if (rt->c[i + 1]->n > t - 1)
//				{//��һ���ڵ��n����t-1
//					auto suc = miniumn(rt->c[i + 1]);
//					auto suc_key = suc->key.front();
//					b_tree_delete_imple(root, suc_key);
//					rt->key[i] = suc_key;
//				}
//				else
//				{//�ϲ�ǰ��ڵ㣬��ʱ�ؼ��ֽ���ǰһ���ڵ㣬�ݹ�ɾ��
//					b_tree_merge(rt, i);
//					b_tree_delete_imple(rt->c[i], k);
//				}
//			}
//		}
//		else
//		{//��ǰ�ڵ㲻�����ؼ���
//			i += 1;
//			auto tar = rt->c[i];//�ؼ������������ĸ��ڵ㣬����ؼ��������еĻ�
//
//			if (tar->n > t - 1)//���ڵ��n����t-1
//				b_tree_delete_imple(tar, k);
//			else
//			{//���ڵ��nС�ڵ���t-1
//				if (!i)
//				{//i=0,û��ǰ���ڵ㣬�����ǰ���ǽ��������ǹؼ���
//					auto suc = rt->c[i + 1];
//					if (suc->n > t - 1)
//					{//ǰ�ڵ�n����t-1
//						left_replace(rt, i);//Ϊ���е�3a���֮һ
//						b_tree_delete_imple(rt->c[i], k);
//					}
//					else
//					{//ǰ��n<=t-1,�ϲ�
//						b_tree_merge(rt, i);
//						b_tree_delete_imple(rt->c[i], k);
//					}
//				}
//				else if (i == rt->n)
//				{//û�к�̽ڵ㣬
//					auto pre = rt->c[i - 1];
//					if (pre->n > t - 1)
//					{
//						right_replace(rt, i);
//						b_tree_delete_imple(rt->c[i], k);
//					}
//					else
//					{
//						b_tree_merge(rt, i - 1);
//						b_tree_delete_imple(rt->c[i - 1], k);
//					}
//				}
//				else
//				{//��ǰ���ͺ�̽ڵ�
//					auto suc = rt->c[i + 1];
//					auto pre = rt->c[i - 1];
//					if (suc->n > t - 1)
//					{
//						left_replace(rt, i);
//						b_tree_delete_imple(rt->c[i], k);
//					}
//					else if (pre->n > t - 1)
//					{
//						right_replace(rt, i);
//						b_tree_delete_imple(rt->c[i], k);
//					}
//					else
//					{
//						b_tree_merge(rt, i);
//						b_tree_delete_imple(rt->c[i], k);
//					}
//				}
//			}
//		}
//	}
//
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		left_replace(link_type rt, size_t i)
//	{
//		auto tar = rt->c[i];
//		auto suc = rt->c[i + 1];
//		tar->key.push_back(rt->key[i]);
//		tar->n += 1;
//
//		rt->key[i] = suc->key.front();
//
//		suc->n -= 1;
//		for (size_t j = 0; j < suc->n; ++j)
//			suc->key[j] = suc->key[j + 1];
//		suc->key.resize(rt->n);
//
//		if (!tar->leaf)
//		{
//			tar->c.push_back(suc->c.front());
//
//			for (size_t j = 0; j <= suc->n; ++j)
//				suc->c[j] = suc->c[j + 1];
//			suc->c.resize(suc->n + 1);
//		}
//	}
//	
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		right_replace(link_type rt, size_t i)
//	{
//		auto tar = rt->c[i];
//		auto pre = rt->c[i - 1];
//
//		tar->key.resize(tar->n + 1);
//		tar->n += 1;
//		for (size_t j = tar->n - 1; j != 0; --j)
//			tar->key[j] = tar->key[j - 1];
//		tar->key[0] = rt->key[i - 1];
//
//		rt->key[i - 1] = pre->key.back();
//		pre->n -= 1;
//		pre->key.resize(pre->n);
//
//		if (!tar->leaf)
//		{
//			tar->c.resize(tar->n + 1);
//			for (size_t j = tar->n; j != 0; --j)
//				tar->c[j] = tar->c[j - 1];
//			tar->c[0] = pre->c.back();
//
//			pre->c.resize(pre->n + 1);
//		}
//	}
//	
//	template<typename key_type, typename Compare = std::less<key_type>>
//	void b_tree_qmj<key_type, Compare>::
//		b_tree_merge(link_type rt, size_t i)
//	{//�ϲ�rt[i]��rt[i+1]
//		auto pre = rt->c[i];//����������ƣ������ڵ�Ĺؼ��ִ�С��Ϊt-1
//		auto suc = rt->c[i + 1];
//		pre->key.resize(2 * t - 1);
//		pre->n = 2 * t - 1;
//		for (size_t j = 0; j < t - 1; ++j)
//			pre->key[j + t] = suc->key[j];
//		pre->key[t - 1] = rt->key[i];
//
//		if (!pre->leaf)
//		{
//			pre->c.resize(2 * t);
//			for (size_t j = 0; j < t; ++j)
//				pre->c[j + t] = suc->c[j];
//		}
//		for (size_t j = i; j < rt->n - 1; ++j)
//			rt->key[j] = rt->key[j + 1];
//		rt->key.resize(rt->n - 1);
//
//		for (size_t j = i + 1; j < rt->n; ++j)
//			rt->c[j] = rt->c[j + 1];
//		rt->n -= 1;
//		rt->c.resize(rt->n + 1);
//	}
//
//}
//
//#endif