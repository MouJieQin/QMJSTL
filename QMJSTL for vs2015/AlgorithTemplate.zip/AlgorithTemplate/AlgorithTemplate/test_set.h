#pragma once
#ifndef _TEST_SET_
#define _TEST_SET_

#include "test.h"
#include "set_qmj.h"
#include <set>

void test_set()
{
	std::vector<int>data_size
		//	{ 0,1,2,5,10,100,1000,10000,100000,1000000};
	{ 1000000 };

	random_data_product(data_size, vt_data, insert_data)

	//	for (int j = 0; j != i; ++j)
	//		vt_data[j] = j;
	//std::random_shuffle(vt_data.begin(), vt_data.end());

	time_counter(
		"init/insert"
		,

		std::multiset<int>std_(vt_data.begin(), vt_data.end());
	
	,

		_QMJ multiset<int>qmj_(vt_data.begin(), vt_data.end());


	,
		i
		)

			time_counter(
				"find"
				,
				for (auto j : vt_data)
					std_.find(j);
	,
		for (auto j : vt_data)
			qmj_.find(j);
	,
		i
		)
		cout << std_.size() << endl;
	cout << qmj_.size() << endl;
	time_counter(
		"access"
		,
		for (auto j : std_)
			;
	,
		for (auto j : qmj_)
			;
	,
		i
		)

		time_counter(
			"erase"
			,
			for (auto j : vt_data)
				std_.erase(j);
	,
		for (auto j : vt_data)
			qmj_.erase(j);
	,
		i
		)


	print_time("set", "std", "qmj")
}


#endif
