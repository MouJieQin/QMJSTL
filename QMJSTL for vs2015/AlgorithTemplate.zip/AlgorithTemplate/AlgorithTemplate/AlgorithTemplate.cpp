#define _SCL_SECURE_NO_WARNINGS 
#include<iostream>
#include<algorithm>
#include<vector>
#include<memory>
#include<queue>
#include<map>
#include<stack>
#include<climits>
#include<iterator>
#include<functional>
#include<string>
#include<list>
#include<unordered_map>
#include<unordered_set>
#include<bitset>
#include<array>
#include<numeric>
#include<allocators>

#include "graph_FS.h"
#include "graph_shortest_path.h"

template<typename Container>
void display(const Container& c)
{
	copy(c.begin(), c.end(), ostream_iterator<typename Container::value_type>(cout, " "));
	cout << endl;
}

template<typename Iter>
void show(Iter first, Iter last)
{

	copy(first, last, ostream_iterator<std::iterator_traits<Iter>::value_type>(cout, " "));
	cout << endl;
}


#include"heap_test.h"
#include"heap.h"
#include"graph.h"
#include"graph_MST.h"
#include"graph_all_shortest_paths.h"
#include"graph_shortest_path.h"
#include"graph_FS.h"
#include"stack_qmj.h"
#include"os_tree.h"
#include"disjoint_set.h"
#include"sort_test.h"
#include"set_qmj.h"
#include"map_qmj.h"
#include"hashtable.h"
#include"unordered_set_qmj.h" 
#include"unordered_map_qmj.h"
#include"test_hash_set.h"
#include"test_set.h"
#include"allocator.h"
#include"vector_qmj.h"
#include"test_vector.h"
#include"list_qmj.h"
#include"test_list.h"
#include"deque_qmj.h"
#include"test_deque.h"
#include"test_stack.h"
#include"forward_list_qmj.h"
#include"forward_list_qmj.h"
#include"test_forward_list.h"
#include"test_algorithm.h"
#include"type_traits_qmj.h"
#include"rb_tree.h"
#include"numeric_qmj.h"
#include"AVL_tree.h"
#include"test_avl_tree.h"
#include"splay_tree.h"
#include"skip_list.h"




int main()
{
	qmj::map<string, int>mp;
	mp.insert({ "fehoie",89 });
	cout << (*mp.begin()).first << endl;

}

















