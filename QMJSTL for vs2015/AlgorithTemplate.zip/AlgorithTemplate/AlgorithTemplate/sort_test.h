#pragma once
#ifndef _SORT_TEST_
#define _SORT_TEST_
#include"test.h"
#include"sort.h"
#include<algorithm>
#include<vector>
#include"algorithm_qmj.h"

void sort_test()
{
	std::vector<int>data_size{0,1,2,5,100,1000,10000,100000,1000000,30000000};//�������ݴ�С

	random_data_product(data_size, vt_data, insert_data)
		std::vector<int>vt(insert_data);
		time_counter(
			"sort",
			std::sort(insert_data.begin(), insert_data.end()); 
	,
			_QMJ sort(vt.begin(), vt.end());
	,
		i
		)
			if (insert_data == vt)
				cout << "�ȶ���ȷ" << endl;
			else
				cout << "�ȶԴ���" << endl;
	print_time("sort","std","qmj")
}

#endif