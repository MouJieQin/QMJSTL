#pragma once
#ifndef _TEST_LIST_
#define _TEST_LIST_
#include<list>
#include<deque>
#include"test.h"
#include"list_qmj.h"

void test_list()
{
	std::vector<int>data_size
	{5000000 };

	random_data_product(data_size, vt_data, insert_data)

		time_counter(
			"init"
			,
			std::list<int>std_(vt_data.begin(), vt_data.end());
	,
		_QMJ list<int>qmj_(vt_data.begin(), vt_data.end());
	,
		i
		)


		time_counter(
			"push_back"
			,
		for (auto i : insert_data)
			std_.push_back(i);
		,
		for (auto i : insert_data)
			qmj_.push_back(i);
		,
			i
			)

			time_counter(
				"assign"
				,
				std_.assign(vt_data.begin(), vt_data.end());
		,
			qmj_.assign(vt_data.begin(), vt_data.end());
		,
			i
			)
			int x = 0;
		time_counter(
			"access"
			,
			for (auto &i : std_)
				x ^= i;
		,
			for (auto &i : qmj_)
				x ^= i;
		,
			i)

			cout << x << endl;

	//	time_counter(
	//		"sort"
	//		,
	//		std_.sort();
	//,
	//	qmj_.sort();
	//,
	//	i)

	//		time_counter(
	//			"unique"
	//			,
	//			std_.unique();
	//,
	//	qmj_.unique();
	//,
	//	i)

	print_time("list", "std", "qmj")
}





#endif