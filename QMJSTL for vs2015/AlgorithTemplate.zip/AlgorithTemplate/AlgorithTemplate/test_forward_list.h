#pragma once
#ifndef _TEST_FORWARD_LIST_
#define _TEST_FORWARD_LIST_
#include"test.h"
#include"forward_list_qmj.h"
#include<forward_list>

void test_forward_list()
{

	std::vector<int>data_size
	{5000000 };

	random_data_product(data_size, vt_data, insert_data)
	time_counter(
		"init"
		,
		std::forward_list<int>std_(vt_data.begin(), vt_data.end());
	,
		_QMJ forward_list<int>qmj_(vt_data.begin(), vt_data.end());
	,
		i
		)

		time_counter(
			"emlace_front"
			,
			for (auto i : insert_data)
				std_.emplace_front(i);
	,
		for (auto i : insert_data)
			qmj_.emplace_front(i);
	,
		i
		)

		time_counter(
			"insert n"
			,
			std_.insert_after(std_.before_begin(), i, 9);
	,
		qmj_.insert_after(qmj_.before_begin(), i, 9);
	,
		i
		)

	//	time_counter(
	//		"sort"
	//		,
	//		std_.sort();
	//,
	//	qmj_.sort();
	//,
	//	i * 2
	//	)

		time_counter(
			"copy_construct"
			,
			std::forward_list<int>cps(std_);
	,
		_QMJ forward_list<int>cpq(qmj_);
	,
		i
		)

	//	time_counter(
	//		"merge"
	//		,
	//		std_.merge(cps);
	//,
	//	qmj_.merge(cpq);
	//,
	//	i * 2*2
	//	)

	//	if (equal(qmj_.begin(), qmj_.end(), std_.begin()))
	//		cout << "�ȶ���ȷ" << endl;
	//	else
	//		cout << "�ȶԴ���" << endl;

	print_time("forward_list", "std", "qmj")

}









#endif
