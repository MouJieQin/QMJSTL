#pragma once
#ifndef _TEST_ALGORITHM_
#define _TEST_ALGORITHM_
#include"test.h"
#include<algorithm>
#include"algorithm_qmj.h"


void test_algorithm()
{
	std::vector<int>data_size
	{10000000 };

	random_data_product(data_size, vt_data, insert_data)
		//std::sort(vt_data.begin(), vt_data.end());
	//for (int j = 0; j != x; ++j)
	//	vt_data[j] = 9;
	//for (int j = x; j != i; ++j)
	//	vt_data[j] = 10;
	for (int j = 0; j != i; ++j)
		vt_data[j] = j;
	//vt_data.push_back(67);
	//std::random_shuffle(vt_data.begin(), vt_data.end());
	//insert_data = vt_data;
	vt_data.insert(vt_data.end() - 10, 100, 9);

	time_counter(
		"stable_sort"
		,
		auto iter1=std::search_n(vt_data.begin(), vt_data.end(),10,9);
	,


		auto iter2=qmj:: search_n (vt_data.begin(), vt_data.end(),50,9);
	,
		i
		)

		if (iter1 == iter2)
		{
			if (iter1 != vt_data.end())
				for (iter1 += 105; iter2 != iter1; ++iter2)
					cout << *iter2 << " ";
			cout << "equal" << endl;
		}
		else
			cout << "not equal" << endl;

		//if (vt_data == insert_data)
		//	cout << "�ȶ���ȷ" << endl;
		//else
		//	cout << "�ȶԴ���" << endl;
	//if (i > 50)
	//	display(insert_data);

	//if (ret1 == ret2)
	//	cout << "�ȶ���ȷ" << endl;
	//else
	//	cout << "�ȶԴ���" << endl;

//if (equal(qmj_.begin(), qmj_.end(), std_.begin()))
//	cout << "�ȶ���ȷ" << endl;
//else
//	cout << "�ȶԴ���" << endl;

	print_time("stable_sort", "std", "qmj")
}



#endif
