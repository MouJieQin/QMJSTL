#pragma once
#ifndef _TEST_HASH_SET_
#define _TEST_HASH_SET_
#include "test.h"
#include<unordered_set>
#include<unordered_map>
#include"unordered_map_qmj.h"
#include "unordered_set_qmj.h"

void test_hash_set()
{
	_QMJ vector<int>data_size
	{1000000};//�������ݴ�С
	random_data_product(data_size, vt_data, insert_data)

		_QMJ vector<int>vt;
	vt.reserve(i * 2);
	for (int j = 0; j != i; ++j)
	{
		vt.push_back(j);
		vt.push_back(i - j);
		vt.push_back(j);
		vt.push_back(i-j);
	}

	std::random_shuffle(vt.begin(), vt.end());
	time_counter(
		"init/insert"
	,
	std::unordered_multiset<int>std_ (vt.begin(), vt.end());
	std::unordered_multiset<int>cpstd_(vt.rbegin(), vt.rend());

	,

	_QMJ unordered_multiset<int>qmj_(vt.begin(), vt.end());
	_QMJ unordered_multiset<int>cpqmj_(vt.rbegin(), vt.rend());
	,
		(int)(2*vt.size())
		)

		time_counter(
			"find"
			,
			for (auto i : vt)
				std_.find(i);
	,
		for (auto i : vt)
			qmj_.find(i);
	,
		(int)vt.size()
		)

		int x = 9;
		time_counter(
			"acccess"
			,
	for (auto i:std_)
		x^=i;
	,
		for (auto i : qmj_)
			x ^= i;
	,
		(int)qmj_.size()
		)
			cout << x << endl;

		time_counter(
			"equal"
			,
			if (std_ == cpstd_)
				cout << "is equal" << endl;
			else
				cout << "not equal" << endl;
	,
		if (qmj_ == cpqmj_)
			cout << "is euqual" << endl;
		else
			cout << "not equal" << endl;
	,
		(int)(qmj_.size())
		)
			cout << std_.size() << "\t" << qmj_.size() << endl;

			time_counter(
				"erase"
				,
				for (auto i : vt)
					std_.erase(i);
	,
		for (auto i : vt)
			qmj_.erase(i);
	,
		(int)vt.size()
		)


	print_time("hash_set", "std", "qmj")

}


#endif
