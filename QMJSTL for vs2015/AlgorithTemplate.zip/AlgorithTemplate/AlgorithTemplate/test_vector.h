#pragma once
#ifndef _test_vector_
#define _test_vector_
#include"test.h"
#include<vector>
#include"vector_qmj.h"

struct bb
{
//	typedef _QMJ true_type is_POD_tag;
	bb() 
	{
	};

	bb(const bb&x)
	{
	}

	~bb()
	{
		//cout << "opfjeo" << endl;
	//	a = 90;
	}

	/*size_t a;
	int on;*/
	int a;
};

//namespace qmj
//{
//	template<>
//	struct type_traits<bb>
//	{
//		typedef true_type is_POD_type;
//	};
//}

bb b ;

bool operator<(const bb&x, const bb&y)
{
	return x.a < y.a;
}

void test_vector()
{
	std::vector<int>data_size
	{ 50000000 };

	random_data_product(data_size, vt_data, insert_data)
		_QMJ vector<int>cp(vt_data.begin(), vt_data.end());
	time_counter(
		"init"
		,
		std::vector<int> std_(vt_data.begin(), vt_data.end());
	,
		_QMJ vector<int>qmj_(cp.begin(), cp.end());
	,
		i
		)

		time_counter(
			"access"
			,
			for (size_t j = 0; j != i; ++j)
				std_[j] = 0;
	,
		for (size_t j = 0; j != i; ++j)
			qmj_[j] = 0;
	,
		i
		)

		time_counter(
			"pop_back"
			,
			while (!std_.empty())
				std_.pop_back();
	,
		while (!qmj_.empty())
			qmj_.pop_back();
	,
		i
		)

	time_counter(
		"assign"
		,
	std_.assign(vt_data.begin(), vt_data.end());
	,
	qmj_.assign(cp.begin(), cp.end());
	,
		i
		)

	time_counter(
		"push_back"
		,
			for (auto i : insert_data)
				std_.push_back(i);
			,
		for (auto i : cp)
			qmj_.push_back(i);
	,
		i
		)

	print_time("vector", "std", "qmj")
}


#endif
